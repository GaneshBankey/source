package com.magento.api.service;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.magento.api.model.Message;
import com.magento.api.model.Status;
import com.magento.api.model.UserAccount;

@Service
public class MagentoServiceImpl implements MagentoService {

	private final HttpHeaders headers = new HttpHeaders();
	
	@Autowired
	@Qualifier("magentoRestTemplate")
	public RestTemplate restTemplate;
	
	@Value("${magento.backend.url}")
	public String backendURL;
	
	@Override
	public Message createNewAccount(UserAccount newAccount) {
		Message message = new Message(Status.FAILURE);
		ResponseEntity<String> respEntity = null;
		HttpEntity<MultiValueMap<String, Object>> entityReq = new HttpEntity<>(this.getMultipartRequest( newAccount), headers);
		
		respEntity = restTemplate
			    .exchange(backendURL, HttpMethod.POST, entityReq, String.class);
		if(respEntity != null && respEntity.getStatusCode().is3xxRedirection()) {
			message.setStatus(Status.SUCCESS);
		}
		return message;
	}
	
	public MultiValueMap<String, Object> getMultipartRequest(UserAccount newAccount){
		
		MultiValueMap<String, Object> multipartRequest = new LinkedMultiValueMap<>();
		
		if(null != newAccount) {
			multipartRequest.add("firstname", newAccount.getFirstname());
			multipartRequest.add("middlename", newAccount.getMiddlename());
			multipartRequest.add("lastname", newAccount.getLastname());
			multipartRequest.add("email", newAccount.getEmail());
			multipartRequest.add("password", newAccount.getPassword());
			multipartRequest.add("confirmation", newAccount.getConfirmation());
			multipartRequest.add("is_subscribed", newAccount.isSubscribed()? 1 : 0);
		}
		return multipartRequest;
	}
	
	@PostConstruct
	public void init() {
		headers.setContentType(MediaType.MULTIPART_FORM_DATA);
	}

}
