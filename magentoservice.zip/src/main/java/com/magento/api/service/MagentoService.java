package com.magento.api.service;

import com.magento.api.model.Message;
import com.magento.api.model.UserAccount;

public interface MagentoService {
	public Message createNewAccount(UserAccount newAccount);
}
