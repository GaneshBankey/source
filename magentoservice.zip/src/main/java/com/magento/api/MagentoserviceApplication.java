package com.magento.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MagentoserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MagentoserviceApplication.class, args);
	}

}
