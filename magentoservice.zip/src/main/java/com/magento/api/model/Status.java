package com.magento.api.model;

public enum Status {
	SUCCESS,
	FAILURE
}
