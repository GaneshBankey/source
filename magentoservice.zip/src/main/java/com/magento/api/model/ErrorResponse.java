package com.magento.api.model;

/**
 * This Model is used for sending the error message to client
 * @author root
 *
 */
public class ErrorResponse {
	private String message;
	public ErrorResponse(String message) {
		this.message = message;
	}
	public String getMessage() {
		return message;
	}
}
