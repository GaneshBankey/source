package com.magento.api.model;

public class Message {
	private Status status;
	public Message(Status status) {
		this.status = status;
	}
	public Status getStatus() {
		return status;
	}
	public void setStatus(Status status) {
		this.status = status;
	}
}
