package com.magento.api.exception;

import java.util.stream.Collectors;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.magento.api.model.ErrorResponse;

@RestControllerAdvice
public class MagentoServiceExceptionHandler {

	//Mapping the UserAccount Required field Validation error
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<ErrorResponse> handleNotFoundException(MethodArgumentNotValidException ex) {
		String errorMsg = ex.getBindingResult().getAllErrors().stream()
			.filter(error -> error instanceof FieldError)
			.map(item -> FieldError.class.cast(item) )
			.map(obj -> obj.getField()+" "+obj.getDefaultMessage())
			.collect(Collectors.joining(";"));
		
		ErrorResponse responseMsg = new ErrorResponse(errorMsg);
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(responseMsg);
	}
}
