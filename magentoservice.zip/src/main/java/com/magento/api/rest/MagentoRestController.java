package com.magento.api.rest;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.magento.api.model.Message;
import com.magento.api.model.UserAccount;
import com.magento.api.service.MagentoService;


@RestController
@RequestMapping("/api")
@Validated
public class MagentoRestController {

	@Autowired
	public MagentoService magentoService;
	
	@PostMapping(path="newaccount", consumes = "application/json", produces="application/json")
	public ResponseEntity<Message> createAccount(@RequestBody @Valid UserAccount newAccount ){
		return ResponseEntity.ok(magentoService.createNewAccount(newAccount));
	}
}
